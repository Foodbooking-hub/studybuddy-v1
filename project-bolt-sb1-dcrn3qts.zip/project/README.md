studybuddy-v1
